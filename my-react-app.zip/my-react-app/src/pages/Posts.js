import ListProducts from './components/ListProducts'

const Posts = () => {
    return <section>
        <h1>Posts</h1>
        <ListProducts />
    </section>
}
export default Posts